#include <iostream>
#include <cstdlib>
#include <mpi.h>
#include <time.h>
#include <iomanip>

#define ITER 10

using namespace std;

void Euler (float& position, float& velocity, float dt, float mass, float force)
{
	velocity = dt * (mass/force) + velocity;
	position = dt * velocity + position; 
}

void RK4 (float& position, float& velocity, float dt, float mass, float T, float C)
{
	float k1 = dt *( 1.0f/mass * ( T - C * velocity) );
	float k2 = dt *( 1.0f/mass * ( T - C * (velocity + k1 /2.0f)) );
	float k3 = dt *( 1.0f/mass * ( T - C * (velocity + k2 /2.0f)) );
	float k4 = dt *( 1.0f/mass * ( T - C * (velocity + k3 )) );

	velocity = velocity + (1.0/6.0f) * ( k1 + 2 * k2 + 2 * k3 + k4 );
	position = dt * velocity + position; 
}

void RK2 (float& position, float& velocity, float dt, float mass, float T, float C)
{
	float k1 = dt *( 1.0f/mass * ( T - C * velocity) );
	float k2 = dt *( 1.0f/mass * ( T - C * (velocity + k1 /2.0f)) );

	velocity = velocity + ( 0.5 * k1 + 0.5 * k2 ) ;
	position = dt * velocity + position; 
}

int main(int argc, char *argv[])
{
	int numprocs, myid;
	MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
    MPI_Comm_rank(MPI_COMM_WORLD, &myid);
	//Exec Time
	clock_t start, end; 
	start = clock();
	{
		cout << "EULER STEP 0.25 second" << endl;
		//Euler
		float velocity = 0.0f;
		float pos = 0.0f;
		float dt = 0.25f;
		float mass = 10.0f;
		float force = 4.0f;

		if(myid==0)
		{
			for(int i = 1; i < numprocs; ++i)
			{
				MPI_Recv(&velocity, ITER, MPI_FLOAT, i, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				MPI_Recv(&pos, ITER, MPI_FLOAT, i, 1, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				for (int i= 0; i<ITER; i++ )
				{
					printf("Step: %d Pos: %.1f Vel: %.1f \n",i,pos,velocity);
				}
			}
		}
		else 
		{
			for (int i= 0; i<ITER; i++ )
			{
				Euler(pos, velocity,dt, mass, force);
				MPI_Send(&velocity, ITER, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
				MPI_Send(&pos, ITER, MPI_FLOAT, 0, 1, MPI_COMM_WORLD);
			}
		}

		for (int i= 0; i<ITER; i++ )
		{
			Euler(pos, velocity,dt, mass, force);
			printf("Step: %d Pos: %.1f Vel: %.1f \n",i,pos,velocity);
		}		
	}

	{
		cout << "RK2 STEP 0.25 SECOND" << endl;
		//RK2
		float pos = 0.0f;
		float velocity = 0.0f;
		float dt = 0.25f;
		float m = 100.0f;

		float T = 100.0f; 
		float C = 1.0f; 

		if(myid==0)
		{
			for(int i = 1; i < numprocs; ++i)
			{
				MPI_Recv(&velocity, ITER, MPI_FLOAT, i, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				MPI_Recv(&pos, ITER, MPI_FLOAT, i, 1, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				for (int i= 0; i<ITER; i++ )
				{
					printf("Step: %d Pos: %.1f Vel: %.1f \n",i,pos,velocity);
				}
			}
		}
		else 
		{
			for (int i= 0; i<ITER; i++ )
			{
				RK2(pos, velocity,dt,m,T,C);
				MPI_Send(&velocity, ITER, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
				MPI_Send(&pos, ITER, MPI_FLOAT, 0, 1, MPI_COMM_WORLD);
			}
		}
	}

	{
		cout << "RK4 STEP 0.25 SECOND" << endl;
		//RK4
		float pos = 0.0f;
		float velocity = 0.0f;
		float dt = 0.25f;
		float m = 100.0f;

		float T = 100.0f; 
		float C = 1.0f; 

		if(myid==0)
		{
			for(int i = 1; i < numprocs; ++i)
			{
				MPI_Recv(&velocity, ITER, MPI_FLOAT, i, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				MPI_Recv(&pos, ITER, MPI_FLOAT, i, 1, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				for (int i= 0; i<ITER; i++ )
				{
					printf("Step: %d Pos: %.1f Vel: %.1f \n",i,pos,velocity);
				}
			}
		}
		else 
		{
			for (int i= 0; i<ITER; i++ )
			{
				RK4(pos, velocity,dt,m,T,C);
				MPI_Send(&velocity, ITER, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
				MPI_Send(&pos, ITER, MPI_FLOAT, 0, 1, MPI_COMM_WORLD);
			}
		}
	}

	MPI_Finalize();

 	end = clock(); 
    // Calculating total time taken by the program. 
    double time_taken = double(end - start) / double(CLOCKS_PER_SEC); 
    cout << "Time taken by program is : " << fixed  << time_taken << setprecision(5); 
    cout << " sec " << endl; 

	return 0;
}