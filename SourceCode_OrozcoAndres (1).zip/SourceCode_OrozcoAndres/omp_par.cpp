#include <iostream>
#include <cstdlib>
#include <omp.h>
#include <time.h>
#include <iomanip>
using namespace std;

#define ITER 3000

void Euler (float& position, float& velocity, float dt, float mass, float force)
{
	velocity = dt * (mass/force) + velocity;
	position = dt * velocity + position; 
}

void RK4 (float& position, float& velocity, float dt, float mass, float T, float C)
{
	float k1 = dt *( 1.0f/mass * ( T - C * velocity) );
	float k2 = dt *( 1.0f/mass * ( T - C * (velocity + k1 /2.0f)) );
	float k3 = dt *( 1.0f/mass * ( T - C * (velocity + k2 /2.0f)) );
	float k4 = dt *( 1.0f/mass * ( T - C * (velocity + k3 )) );

	velocity = velocity + (1.0/6.0f) * ( k1 + 2 * k2 + 2 * k3 + k4 );
	position = dt * velocity + position; 
}

void RK2 (float& position, float& velocity, float dt, float mass, float T, float C)
{
	float k1 = dt *( 1.0f/mass * ( T - C * velocity) );
	float k2 = dt *( 1.0f/mass * ( T - C * (velocity + k1 /2.0f)) );

	velocity = velocity + ( 0.5 * k1 + 0.5 * k2 ) ;
	position = dt * velocity + position; 
}

int main()
{
	//Exec Time
	clock_t start, end; 
	start = clock();
	{
		cout << "EULER STEP 0.25 second" << endl;
		//Euler
		float velocity = 0.0f;
		float pos = 0.0f;
		float dt = 0.25f;
		float mass = 10.0f;
		float force = 4.0f;

		#pragma omp parallel for schedule(dynamic) shared(pos,velocity)
		for (int i= 0; i<ITER; i++ )
		{
			Euler(pos, velocity,dt, mass, force);
			printf("Step: %d Pos: %.1f Vel: %.1f \n",i,pos,velocity);
		}		
	}

	{
		cout << "RK2 STEP 0.25 SECOND" << endl;
		//RK2
		float pos = 0.0f;
		float velocity = 0.0f;
		float dt = 0.25f;
		float m = 100.0f;

		float T = 100.0f; 
		float C = 1.0f; 

		#pragma omp parallel for schedule(dynamic) shared(pos,velocity)
		for ( int i= 0; i<ITER; i++ )
		{
			RK2(pos, velocity,dt,m,T,C);
			printf("Step: %d Pos: %.1f Vel: %.1f \n",i,pos,velocity);
		}
	}

	{
		cout << "RK4 STEP 0.25 SECOND" << endl;
		//RK4
		float pos = 0.0f;
		float velocity = 0.0f;
		float dt = 0.25f;
		float m = 100.0f;

		float T = 100.0f; 
		float C = 1.0f; 

		#pragma omp parallel for schedule(dynamic) shared(pos,velocity)
		for ( int i= 0; i<ITER; i++ )
		{
			RK4(pos, velocity,dt,m,T,C);
			printf("Step: %d Pos: %.1f Vel: %.1f \n",i,pos,velocity);
		}
	}

 	end = clock(); 
    // Calculating total time taken by the program. 
    double time_taken = double(end - start) / double(CLOCKS_PER_SEC); 
    cout << "Time taken by program is : " << fixed  << time_taken << setprecision(5); 
    cout << " sec " << endl; 

	return 0;
}